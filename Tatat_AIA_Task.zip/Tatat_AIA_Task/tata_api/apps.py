from django.apps import AppConfig


class TataApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tata_api'
